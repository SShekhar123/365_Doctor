<?php
echo '<style>';
echo '#health{';
echo 'font-weight: bold;';
echo 'font-size:5vw;';
echo 'font-family:Calibri;}';
echo 'border-style: dotted;}';
echo '</style>';
$msg = 'Healthy outside will start from inside';
$l = strlen($msg);
if($l>200){
echo "<center><p id='health' style='color:#ffffff; background-color:#1aff00; height:750px; width:750px;'>". $msg ."</p></center>";
}
if($l>150){
echo "<center><p id='health' style='color:#ffffff; background-color:#1aff00; height:600px; width:600px;'>". $msg ."</p></center>";
}
if($l>100){
echo "<center><p id='health' style='color:#ffffff; background-color:#1aff00; height:500px; width:600px;'>". $msg ."</p></center>";
}
if($l<50){
echo "<center><p id='health' style='color:#ffffff; background-color:#1aff00; height:400px; width:600px;'>". $msg ."</p></center>";
}
else{
echo "<center><p id='health' style='color:#ffffff; background-color:#1aff00; height:300px; width:600px;'>". $msg ."</p></center>";
}
?>